//Wizard Staff Mod V2.0 - Added Equal Trade Focus
//By wilco375
//Do not re-upload, only share using the minecraftforum and/or adf.ly link

var selectedFocus
var activeFocus = "floating";
var y;
var prevY;
var staffButton = false;
var resourcesDownloaded = false;
var GUIButtonImageView

//Ids
var staffId = 510;
var staffDurability
var portableHoleId = 410
var harmingIId = 411
var harmingIIId = 412
var healingId = 413
var floatingId = 414
var shieldingId = 415
var relocationId = 416
var equalTradeId = 417


//Floating Variables
var tickcount = 0
var watertickcount = 0
var floatPrevHealth
var falling = false

//Portable Hole Variables
var pHoleId = 450
var pHoleActive
var PortalOpenedTimeInTicks = 60

//Shield Variables
var shieldCountDown
var shieldCoolDown 
var shieldActive
var shieldPrevHealth

//Relocation Variables
var moveBlock
var moveBlockId
var moveBlockData

//Equal Trade Variables
var equalTradeBlocks=[];
var blocksReplaced = 0;

ModPE.setItem(staffId,"stick",0,"Wizard Staff");
Item.addShapedRecipe(staffId, 1, 0, [
"  d",
" s ",
"d  "
], 
["d", 264, 0, "s", 280, 0]); 
Item.setMaxDamage(staffId,4096)
ModPE.setItem(portableHoleId,"dye_powder",4,"Portable Hole Focus");
Item.addCraftRecipe(portableHoleId,1,0,[265,4,0,57,1,0,265,4,0])
ModPE.setItem(harmingIId,"dye_powder",7,"Harming I Focus");
Item.addCraftRecipe(harmingIId,1,0,[265,4,0,42,1,0,265,4,0])
ModPE.setItem(harmingIIId,"dye_powder",8,"Harming II Focus");
Item.addCraftRecipe(harmingIIId,1,0,[264,1,0,265,1,0,264,1,0,265,1,0,42,1,0,265,1,0,264,1,0,265,1,0,264,1,0])
ModPE.setItem(healingId,"dye_powder",1,"Healing Focus");
Item.addCraftRecipe(healingId,1,0,[266,1,0,264,1,0,266,2,0,360,1,0,266,2,0,264,1,0,266,1,0])
ModPE.setItem(floatingId,"dye_powder",9,"Floating Focus");
Item.addCraftRecipe(floatingId,1,0,[288,1,0,264,1,0,288,1,0,264,1,0,42,1,0,264,1,0,288,1,0,264,1,0,288,1,0])
ModPE.setItem(shieldingId,"dye_powder",11,"Shielding Focus");
Item.addCraftRecipe(shieldingId,1,0,[265,1,0,306,1,0,265,1,0,307,1,0,57,1,0,308,1,0,265,1,0,309,1,0,265,1,0])
ModPE.setItem(relocationId,"dye_powder",14,"Relocation Focus");
Item.addCraftRecipe(relocationId,1,0,[264,1,0,54,1,0,264,1,0,54,1,0,42,1,0,54,1,0,264,1,0,54,1,0,264,1,0])
ModPE.setItem(equalTradeId,"dye_powder",10,"Equal Trade Focus");
Item.addCraftRecipe(equalTradeId,1,0,[265,1,0,54,1,0,265,1,0,264,1,0,57,1,0,264,1,0,265,1,0,54,1,0,265,1,0])

function newLevel(){
	var activity = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();    
	activity.runOnUiThread(new java.lang.Runnable({ run: function() {
        try{
			shieldingFile = new java.io.File(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/equalTrade.png");
			if(!shieldingFile.exists()){
				android.widget.Toast.makeText(activity,"Couldn't find image files. Have you put the necessary files in Local Storage/games/com.mojang/WizardStaffMod ?",android.widget.Toast.LENGTH_LONG).show();
			}	
		}catch(e){
			print(e)
		}
	}}));
	var out=new java.io.ByteArrayOutputStream();
	var response=android.net.http.AndroidHttpClient.newInstance("Online()").execute(new org.apache.http.client.methods.HttpGet("https://raw.githubusercontent.com/wilco375/Minecraft-PE-Mod-Scripts/master/Wizard_Staff_Mod_V2.0_update_checker.txt")).getEntity().writeTo(out);
	out.close();
	clientMessage(String(out.toString()))
	
	equalTradeBlocks=[];
}

function modTick(){
	if(Player.getCarriedItem() == staffId){
		activeFocus = selectedFocus
		if(!staffButton){
			showButton()
		}
	}
	else{
		if(staffButton){
			hideButton()
		}
		activeFocus = null
	}
	
	//Floating Code
	if(activeFocus == "floating"){
		y = getPlayerY();
		if(getPlayerY != null){
			if(prevY > y){
				if(!falling){
					Entity.setVelY(getPlayerEnt(),-0.2);
					Player.setHealth(10000)
					floatPrevHealth = Entity.getHealth(getPlayerEnt())
					falling = true
				}
				else{
					Entity.setVelY(getPlayerEnt(),-0.2)
					for(i = 0;i<=10;i++){
						Level.addParticle(ParticleType.cloud,getPlayerX()+Math.random() * 2-1,getPlayerY()-2,getPlayerZ()+Math.random() * 2-1,0,0,0,1)
						//clientMessage("particle")
					}
					removeDurability(2)
				}
			}
			else if(falling){
				falling = false
				Player.setHealth(floatPrevHealth)
			}
		}
	}
	prevY = getPlayerY();
	
	//Shielding Code
	if(shieldActive && shieldCountDown != 0){
		shieldCountDown--
		for(i = 0;i<=5;i++){
			Level.addParticle(ParticleType.flame,getPlayerX()+Math.random() * 2-1,getPlayerY()+Math.random() * 2-2,getPlayerZ()+Math.random() * 2-1,0,0,0,1)
		}
	}
	else if(shieldCountDown == 0){
		shieldCoolDown = 600
		shieldCountDown = null
		shieldActive = false
		Player.setHealth(shieldPrevHealth)
	}
	if(shieldCoolDown != null && shieldCoolDown != 0){
		shieldCoolDown--
	}
	else if(shieldCoolDown == 0){
		shieldCoolDown = null
	}
	
	//Portable Hole Code
	if((pHoleActive == 1)){
		if(countdown != 0) countdown--;
		if(countdown == 0) {
			pHoleActive = 0;
			if(BlockSide == 2 || BlockSide == 3){
				setTile(pHoleX,pHoleY, pHoleZ,block1, blockdata1)
				setTile(pHoleX+1,pHoleY,pHoleZ,block2, blockdata2)
				setTile(pHoleX+1,pHoleY+1,pHoleZ,block3, blockdata3)
				setTile(pHoleX+1,pHoleY-1,pHoleZ,block4, blockdata4)
				setTile(pHoleX-1,pHoleY,pHoleZ,block5, blockdata5)
				setTile(pHoleX-1,pHoleY+1,pHoleZ,block6, blockdata6)
				setTile(pHoleX-1,pHoleY-1,pHoleZ,block7, blockdata7)
				setTile(pHoleX,pHoleY+1,pHoleZ,block8, blockdata8)
				setTile(pHoleX,pHoleY-1,pHoleZ,block9), blockdata9
			}
			else if(BlockSide == 4 || BlockSide == 5){
				setTile(pHoleX,pHoleY, pHoleZ,block1, blockdata1)
				setTile(pHoleX,pHoleY,pHoleZ+1,block2, blockdata2)
				setTile(pHoleX,pHoleY+1,pHoleZ+1,block3, blockdata3)
				setTile(pHoleX,pHoleY-1,pHoleZ+1,block4, blockdata4)
				setTile(pHoleX,pHoleY,pHoleZ-1,block5, blockdata5)
				setTile(pHoleX,pHoleY+1,pHoleZ-1,block6, blockdata6)
				setTile(pHoleX,pHoleY-1,pHoleZ-1,block7, blockdata7)
				setTile(pHoleX,pHoleY+1,pHoleZ,block8, blockdata8)
				setTile(pHoleX,pHoleY-1,pHoleZ,block9, blockdata9)
			}
			else if(BlockSide == 1 || BlockSide == 0){
				setTile(pHoleX,pHoleY, pHoleZ,block1, blockdata1)
				setTile(pHoleX,pHoleY,pHoleZ+1,block2, blockdata2)
				setTile(pHoleX+1,pHoleY,pHoleZ+1,block3, blockdata3)
				setTile(pHoleX-1,pHoleY,pHoleZ+1,block4, blockdata4)
				setTile(pHoleX,pHoleY,pHoleZ-1,block5, blockdata5)
				setTile(pHoleX+1,pHoleY,pHoleZ-1,block6, blockdata6)
				setTile(pHoleX-1,pHoleY,pHoleZ-1,block7, blockdata7)
				setTile(pHoleX+1,pHoleY,pHoleZ,block8, blockdata8)
				setTile(pHoleX-1,pHoleY,pHoleZ,block9, blockdata9)
			}
		}
	}
	
	//Equal Trade code
	if(equalTradeBlocks[0]){
		for(var i=0;i<equalTradeBlocks.length;i++){
			if(Level.getTile(equalTradeBlocks[i][0],equalTradeBlocks[i][1],equalTradeBlocks[i][2])==0)
				equalTradeBlocks.splice(i,1);
		}
		var sides=[[equalTradeBlocks[0][0],equalTradeBlocks[0][1]-1,equalTradeBlocks[0][2]],[equalTradeBlocks[0][0],equalTradeBlocks[0][1]+1,equalTradeBlocks[0][2]],[equalTradeBlocks[0][0],equalTradeBlocks[0][1],equalTradeBlocks[0][2]-1],[equalTradeBlocks[0][0],equalTradeBlocks[0][1],equalTradeBlocks[0][2]+1],[equalTradeBlocks[0][0]-1,equalTradeBlocks[0][1],equalTradeBlocks[0][2]],[equalTradeBlocks[0][0]+1,equalTradeBlocks[0][1],equalTradeBlocks[0][2]]];
		for(var i=0;i<6;i++){
			if(Level.getTile(sides[i][0],sides[i][1],sides[i][2])==blockToReplace && Level.getData(sides[i][0],sides[i][1],sides[i][2])==blockToReplaceData)
				equalTradeBlocks.push([sides[i][0],sides[i][1],sides[i][2]]);
		}
		if(Level.getTile(equalTradeBlocks[0][0],equalTradeBlocks[0][1],equalTradeBlocks[0][2])==blockToReplace && Level.getData(equalTradeBlocks[0][0],equalTradeBlocks[0][1],equalTradeBlocks[0][2])==blockToReplaceData){
			if(Player.checkForInventoryItem(blockToSetTo,1,blockToSetToData)){
				Level.setTile(equalTradeBlocks[0][0],equalTradeBlocks[0][1],equalTradeBlocks[0][2],blockToSetTo,blockToSetToData);
				removeDurability(8)
				addItemInventory(blockToReplace,1,blockToReplaceData)
				//clientMessage("blockToSetToData 2 = "+blockToSetToData)
				removeOneBlockFromInventory()
				
				blocksReplaced++
			}else{
				equalTradeBlocks = []
				blocksReplaced = 0
			}
		}
		equalTradeBlocks.splice(0,1);
	}
	if(blocksReplaced>=32){
		equalTradeBlocks = []
		blocksReplaced = 0
	}
}

function useItem(x,y,z,itemId,blockId,side){
	//if(!resourcesDownloaded){
	//	downloadResources()
	//}
	
	//More Equal Trade Code
	if(activeFocus == "equalTrade"){
		equalTradeBlocks=[];
		preventDefault();
		blocksReplaced = 0
		blockToReplace = blockId
		blockToReplaceData = Level.getData(x,y,z)
		blockToSetTo = Player.getInventorySlot(Player.getSelectedSlotId()+1)
		blockToSetToData = Player.getInventorySlotData(Player.getSelectedSlotId()+1)
		if(blockToSetTo<=256)
			equalTradeBlocks.push([x,y,z]);
	}
	
	//More Shielding Code
	if(activeFocus == "shielding"){
		if(shieldCoolDown > 0 && shieldCoolDown < 600){
			clientMessage("Shield is on cooldown, please wait "+Math.round(shieldCoolDown/20)+" more seconds")
		}
		else if(shieldCountDown > 0 && shieldCoolDown < 300){
			clientMessage("Shield is already active. It will last "+Math.round(shieldCountDown/20)+ " more seconds")
		}
		else{
			shieldActive = true
			clientMessage("Shield will now be active for 15 seconds")
			shieldCountDown = 300
			shieldPrevHealth = Entity.getHealth(getPlayerEnt())
			Player.setHealth(10000)
			removeDurability(256)
		}
	}
	
	//Relocation code
	if(activeFocus == "relocation"){
		relocateBlock(x,y,z,itemId,blockId,side)
		removeDurability(256)
	}
	
	//More Portable Hole Code
	if(activeFocus == "portableHole" && blockId != 7){
		if(pHoleActive == 1) clientMessage("Portable Hole is already active!")
		else{
			pHoleX = x
			pHoleY = y
			pHoleZ = z
			countdown = PortalOpenedTimeInTicks
			pHoleActive = 1
			BlockSide = side
			removeDurability(64)
			if(BlockSide == 2 || BlockSide == 3){
				block1 = getTile(pHoleX,pHoleY, pHoleZ)
				block2 = getTile(pHoleX+1,pHoleY,pHoleZ)
				block3 = getTile(pHoleX+1,pHoleY+1,pHoleZ)
				block4 = getTile(pHoleX+1,pHoleY-1,pHoleZ)
				block5 = getTile(pHoleX-1,pHoleY,pHoleZ)
				block6 = getTile(pHoleX-1,pHoleY+1,pHoleZ)
				block7 = getTile(pHoleX-1,pHoleY-1,pHoleZ)
				block8 = getTile(pHoleX,pHoleY+1,pHoleZ)
				block9 = getTile(pHoleX,pHoleY-1,pHoleZ)
				blockdata1 = Level.getData(pHoleX,pHoleY, pHoleZ)
				blockdata2 = Level.getData(pHoleX+1,pHoleY,pHoleZ)
				blockdata3 = Level.getData(pHoleX+1,pHoleY+1,pHoleZ)
				blockdata4 = Level.getData(pHoleX+1,pHoleY-1,pHoleZ)
				blockdata5 = Level.getData(pHoleX-1,pHoleY,pHoleZ)
				blockdata6 = Level.getData(pHoleX-1,pHoleY+1,pHoleZ)
				blockdata7 = Level.getData(pHoleX-1,pHoleY-1,pHoleZ)
				blockdata8 = Level.getData(pHoleX,pHoleY+1,pHoleZ)
				blockdata9 = Level.getData(pHoleX,pHoleY-1,pHoleZ)
				setTile(pHoleX,pHoleY, pHoleZ,0)
				setTile(pHoleX+1,pHoleY,pHoleZ,0)
				setTile(pHoleX+1,pHoleY+1,pHoleZ,0)
				setTile(pHoleX+1,pHoleY-1,pHoleZ,0)
				setTile(pHoleX-1,pHoleY,pHoleZ,0)
				setTile(pHoleX-1,pHoleY+1,pHoleZ,0)
				setTile(pHoleX-1,pHoleY-1,pHoleZ,0)
				setTile(pHoleX,pHoleY+1,pHoleZ,0)
				setTile(pHoleX,pHoleY-1,pHoleZ,0)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+1+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+1+Math.random()-0.5,pHoleY+1+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+1+Math.random()-0.5,pHoleY-1+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX-1+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX-1+Math.random()-0.5,pHoleY+1+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX-1+Math.random()-0.5,pHoleY-1+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+1+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY-1+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
			}
			else if(BlockSide == 4 || BlockSide == 5){
				block1 = getTile(pHoleX,pHoleY, pHoleZ)
				block2 = getTile(pHoleX,pHoleY,pHoleZ+1)
				block3 = getTile(pHoleX,pHoleY+1,pHoleZ+1)
				block4 = getTile(pHoleX,pHoleY-1,pHoleZ+1)
				block5 = getTile(pHoleX,pHoleY,pHoleZ-1)
				block6 = getTile(pHoleX,pHoleY+1,pHoleZ-1)
				block7 = getTile(pHoleX,pHoleY-1,pHoleZ-1)
				block8 = getTile(pHoleX,pHoleY+1,pHoleZ)
				block9 = getTile(pHoleX,pHoleY-1,pHoleZ)
				blockdata1 = Level.getData(pHoleX,pHoleY, pHoleZ)
				blockdata2 = Level.getData(pHoleX,pHoleY,pHoleZ+1)
				blockdata3 = Level.getData(pHoleX,pHoleY+1,pHoleZ+1)
				blockdata4 = Level.getData(pHoleX,pHoleY-1,pHoleZ+1)
				blockdata5 = Level.getData(pHoleX,pHoleY,pHoleZ-1)
				blockdata6 = Level.getData(pHoleX,pHoleY+1,pHoleZ-1)
				blockdata7 = Level.getData(pHoleX,pHoleY-1,pHoleZ-1)
				blockdata8 = Level.getData(pHoleX,pHoleY+1,pHoleZ)
				blockdata9 = Level.getData(pHoleX,pHoleY-1,pHoleZ)
				setTile(pHoleX,pHoleY, pHoleZ)
				setTile(pHoleX,pHoleY,pHoleZ+1)
				setTile(pHoleX,pHoleY+1,pHoleZ+1)
				setTile(pHoleX,pHoleY-1,pHoleZ+1)
				setTile(pHoleX,pHoleY,pHoleZ-1)
				setTile(pHoleX,pHoleY+1,pHoleZ-1)
				setTile(pHoleX,pHoleY-1,pHoleZ-1)
				setTile(pHoleX,pHoleY+1,pHoleZ)
				setTile(pHoleX,pHoleY-1,pHoleZ)	
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+1+Math.random()-0.5,pHoleZ+1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY-1+Math.random()-0.5,pHoleZ+1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ-1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+1+Math.random()-0.5,pHoleZ-1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY-1+Math.random()-0.5,pHoleZ-1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+1+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY-1+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
			}	
			else if(BlockSide == 1 || BlockSide == 0){
				block1 = getTile(pHoleX,pHoleY, pHoleZ)
				block2 = getTile(pHoleX,pHoleY,pHoleZ+1)
				block3 = getTile(pHoleX+1,pHoleY,pHoleZ+1)
				block4 = getTile(pHoleX-1,pHoleY,pHoleZ+1)
				block5 = getTile(pHoleX,pHoleY,pHoleZ-1)
				block6 = getTile(pHoleX+1,pHoleY,pHoleZ-1)
				block7 = getTile(pHoleX-1,pHoleY,pHoleZ-1)
				block8 = getTile(pHoleX+1,pHoleY,pHoleZ)
				block9 = getTile(pHoleX-1,pHoleY,pHoleZ)
				blockdata1 = Level.getData(pHoleX,pHoleY, pHoleZ)
				blockdata2 = Level.getData(pHoleX,pHoleY,pHoleZ+1)
				blockdata3 = Level.getData(pHoleX+1,pHoleY,pHoleZ+1)
				blockdata4 = Level.getData(pHoleX-1,pHoleY,pHoleZ+1)
				blockdata5 = Level.getData(pHoleX,pHoleY,pHoleZ-1)
				blockdata6 = Level.getData(pHoleX+1,pHoleY,pHoleZ-1)
				blockdata7 = Level.getData(pHoleX-1,pHoleY,pHoleZ-1)
				blockdata8 = Level.getData(pHoleX+1,pHoleY,pHoleZ)
				blockdata9 = Level.getData(pHoleX-1,pHoleY,pHoleZ)
				setTile(pHoleX,pHoleY, pHoleZ)
				setTile(pHoleX,pHoleY,pHoleZ+1)
				setTile(pHoleX+1,pHoleY,pHoleZ+1)
				setTile(pHoleX-1,pHoleY,pHoleZ+1)
				setTile(pHoleX,pHoleY,pHoleZ-1)
				setTile(pHoleX+1,pHoleY,pHoleZ-1)
				setTile(pHoleX-1,pHoleY,pHoleZ-1)
				setTile(pHoleX+1,pHoleY,pHoleZ)
				setTile(pHoleX-1,pHoleY,pHoleZ)	
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+1+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX-1+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ-1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+1+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ-1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX-1+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ-1+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX+1+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
				Level.addParticle(ParticleType.lava,pHoleX-1+Math.random()-0.5,pHoleY+Math.random()-0.5,pHoleZ+Math.random()-0.5,0,0,0,5)
			}
		}
	}
	
	//Healing Code
	if(activeFocus == "healing"){
		var newPlayerHealth = Entity.getHealth(getPlayerEnt())+1
		if(newPlayerHealth > 20){
			Player.setHealth(20)
			removeDurability(128)
		}
		else{
			Player.setHealth(newPlayerHealth)
		}
		for(i = 0;i<=64;i++){
			Level.addParticle(ParticleType.heart,getPlayerX()+Math.random() * 2-1,getPlayerY()+Math.random() * 2-2,getPlayerZ()+Math.random() * 2-1,0,0.2,0,1)
		}
	}
}

function attackHook(attacker,victim){
	//Harming Code
	if(attacker == getPlayerEnt()){
		if(activeFocus == "harmingI"){
			if(Entity.getHealth(victim)-5 <= 0){
				Entity.setHealth(victim,1)
				Entity.setFireTicks(victim,1)
				removeDurability(12)
			}
			else{
				Entity.setHealth(victim,Entity.getHealth(victim)-6)
				removeDurability(12)
				Entity.setFireTicks(victim,2)
			}
		}
		else if(activeFocus == "harmingII"){
			if(Entity.getHealth(victim)-9 <= 0){
				Entity.setHealth(victim,1)
				Entity.setFireTicks(victim,1)
				removeDurability(16)
			}
			else{
				Entity.setHealth(victim,Entity.getHealth(victim)-10)
				Entity.setFireTicks(victim,2)
				removeDurability(16)
			}
		}
	}
}

//More Shielding Code
function leaveGame(){
	if(shieldActive){
		shieldActive = false
		Player.setHealth(shieldPrevHealth)
	}
	if(staffButton){
		hideButton()
	}
}

function showButton(){
	var activity = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();    
	activity.runOnUiThread(new java.lang.Runnable({ run: function() {
        try{
			buttonWindow = new android.widget.PopupWindow();
			var layout = new android.widget.LinearLayout(activity);
			layout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
			
			GUIButtonImageView = new android.widget.ImageView(activity);
			imageBitmapEmpty = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/empty.png");
			imageBitmap1 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/portableHole.png");
			imageBitmap2 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/harmingI.png");
			imageBitmap3 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/harmingII.png");
			imageBitmap4 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/healing.png");
			imageBitmap5 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/floating.png");
			imageBitmap6 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/shielding.png");
			imageBitmap7 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/relocation.png");
			imageBitmap8 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/equalTrade.png");
			if(selectedFocus == "portableHole")
				GUIButtonImageView.setImageBitmap(imageBitmap1)
			else if(selectedFocus == "harmingI")
				GUIButtonImageView.setImageBitmap(imageBitmap2)
			else if(selectedFocus == "harmingII")
				GUIButtonImageView.setImageBitmap(imageBitmap3)
			else if(selectedFocus == "healing")
				GUIButtonImageView.setImageBitmap(imageBitmap4)
			else if(selectedFocus == "floating")
				GUIButtonImageView.setImageBitmap(imageBitmap5)
			else if(selectedFocus == "shielding")
				GUIButtonImageView.setImageBitmap(imageBitmap6)
			else if(selectedFocus == "relocation")
				GUIButtonImageView.setImageBitmap(imageBitmap7)
			else if(selectedFocus == "equalTrade")
				GUIButtonImageView.setImageBitmap(imageBitmap8)
			else{
				GUIButtonImageView.setImageBitmap(imageBitmapEmpty);
			}
			GUIButtonImageView.setScaleType(android.widget.ImageView.ScaleType.FIT_XY);
			GUIButtonImageView.setOnClickListener(new android.view.View.OnClickListener({
				onClick: function(viewarg) {
					changeFocusGUI()
				}
			}));
			layout.addView(GUIButtonImageView);
			
			buttonWindow.setContentView(layout);
			buttonWindow.setWidth(100);
			buttonWindow.setHeight(100);
			buttonWindow.showAtLocation(activity.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 0, 0);
        }catch(problem){
          print("Button could not be displayed: " + problem);
        }
  }}));
  staffButton = true
}


function hideButton(){
	if(staffButton){
		var activity = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
		activity.runOnUiThread(new java.lang.Runnable({ run: function() {
			if(buttonWindow != null) {
			buttonWindow.dismiss();
			buttonwindow = null;
			}
		}}));
		staffButton = false
	}
}

function changeFocusGUI(){
	var activity = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();    
	activity.runOnUiThread(new java.lang.Runnable({ run: function() {
        try{
			dialog = new android.app.Dialog(activity);
			dialog.getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
			dialog.setTitle("Pick a focus");
			linearLayout = new android.widget.LinearLayout(activity);
			linearLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
			
			if(itemInInventory(portableHoleId)){
				imageBitmap1 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/portableHole.png");
				imageView1 = new android.widget.ImageView(activity);
				imageView1.setImageBitmap(imageBitmap1);
				imageView1.setOnClickListener(new android.view.View.OnClickListener({
					onClick: function(viewarg) {
						selectedFocus = "portableHole";
						GUIButtonImageView.setImageBitmap(imageBitmap1);
						dialog.dismiss();
					}
				}));
				linearLayout.addView(imageView1);
			}
			if(itemInInventory(harmingIId)){
				imageBitmap2 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/harmingI.png");
				imageView2 = new android.widget.ImageView(activity);
				imageView2.setImageBitmap(imageBitmap2);
				imageView2.setOnClickListener(new android.view.View.OnClickListener({
					onClick: function(viewarg) {
						selectedFocus = "harmingI";
						GUIButtonImageView.setImageBitmap(imageBitmap2);
						dialog.dismiss();
					}
				}));
				linearLayout.addView(imageView2);
			}
			if(itemInInventory(harmingIIId)){
				imageBitmap3 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/harmingII.png");
				imageView3 = new android.widget.ImageView(activity);
				imageView3.setImageBitmap(imageBitmap3);
				imageView3.setOnClickListener(new android.view.View.OnClickListener({
					onClick: function(viewarg) {
						selectedFocus = "harmingII";
						GUIButtonImageView.setImageBitmap(imageBitmap3);
						dialog.dismiss();
					}
				}));
				linearLayout.addView(imageView3);
			}
			if(itemInInventory(healingId)){
				imageBitmap4 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/healing.png");
				imageView4 = new android.widget.ImageView(activity);
				imageView4.setImageBitmap(imageBitmap4);
				imageView4.setOnClickListener(new android.view.View.OnClickListener({
					onClick: function(viewarg) {
						selectedFocus = "healing";
						GUIButtonImageView.setImageBitmap(imageBitmap4);
						dialog.dismiss();
					}
				}));
				linearLayout.addView(imageView4);
			}
			if(itemInInventory(floatingId)){
				imageBitmap5 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/floating.png");
				imageView5 = new android.widget.ImageView(activity);
				imageView5.setImageBitmap(imageBitmap5);
				imageView5.setOnClickListener(new android.view.View.OnClickListener({
					onClick: function(viewarg) {
						selectedFocus = "floating";
						GUIButtonImageView.setImageBitmap(imageBitmap5);
						dialog.dismiss();
					}
				}));
				linearLayout.addView(imageView5);
			}
			if(itemInInventory(shieldingId)){
				imageBitmap6 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/shielding.png");
				imageView6 = new android.widget.ImageView(activity);
				imageView6.setImageBitmap(imageBitmap6);
				imageView6.setOnClickListener(new android.view.View.OnClickListener({
					onClick: function(viewarg) {
						selectedFocus = "shielding";
						GUIButtonImageView.setImageBitmap(imageBitmap6);
						dialog.dismiss();
					}
				}));
				linearLayout.addView(imageView6);
			}
			if(itemInInventory(relocationId)){
				imageBitmap7 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/relocation.png");
				imageView7 = new android.widget.ImageView(activity);
				imageView7.setImageBitmap(imageBitmap7);
				imageView7.setOnClickListener(new android.view.View.OnClickListener({
					onClick: function(viewarg) {
						selectedFocus = "relocation";
						GUIButtonImageView.setImageBitmap(imageBitmap7);
						dialog.dismiss();
					}
				}));
				linearLayout.addView(imageView7);
			}
			if(itemInInventory(equalTradeId)){
				imageBitmap8 = android.graphics.BitmapFactory.decodeFile(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/equalTrade.png");
				imageView8 = new android.widget.ImageView(activity);
				imageView8.setImageBitmap(imageBitmap8);
				imageView8.setOnClickListener(new android.view.View.OnClickListener({
					onClick: function(viewarg) {
						selectedFocus = "equalTrade";
						GUIButtonImageView.setImageBitmap(imageBitmap8);
						dialog.dismiss();
					}
				}));
				linearLayout.addView(imageView8);
			}
			if(linearLayout.getChildCount()==0){
				textView = new android.widget.TextView(activity)
				textView.setTextColor(android.graphics.Color.WHITE)
				textView.setText("Please craft a focus to use the staff")
				textView.setPadding(10,10,10,10)
				linearLayout.addView(textView)
			}
			dialog.setContentView(linearLayout);
			dialog.show();
			dialog.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        }catch(problem){
			print("Dialog could not be displayed: " + problem);
        }
  }}));
}

function itemInInventory(id){
	var inInventory = false
	for(i = 0;i<43;i++){
		if(Player.getInventorySlot(i) == id){
			return true
			inInventory = true
			break
		}
	}
	if(!inInventory) return false
}

function removeDurability(damage){
	if(Player.getCarriedItemData()+damage<4096)
		Entity.setCarriedItem(getPlayerEnt(),Player.getCarriedItem(),Player.getCarriedItemCount(),Player.getCarriedItemData()+damage)
	else{
		Entity.setCarriedItem(getPlayerEnt(),0)
	}
}

//More relocation code
function relocateBlock(x,y,z,itemId,blockId,side){
	preventDefault()
	if(moveBlock != 1){
		moveBlock = 1
		if(blockId != 54 && blockId != 7 && blockId != 61 && blockId != 62){
			moveBlockId = blockId
			moveBlockData = Level.getData(x,y,z)
			setTile(x,y,z,0,0)
		}
		
		else if(blockId == 61 || blockId == 62){
			moveBlockId = blockId;
			moveBlockData = Level.getData(x,y,z)
			FurnaceSlotId0 = Level.getFurnaceSlot(x,y,z,0);
			FurnaceSlotCount0 = Level.getFurnaceSlotCount(x,y,z,0);
			FurnaceSlotData0 = Level.getFurnaceSlotData(x,y,z,0);
			Level.setFurnaceSlot(x,y,z,0,0,0,0)
			FurnaceSlotId1 = Level.getFurnaceSlot(x,y,z,1);
			FurnaceSlotCount1 = Level.getFurnaceSlotCount(x,y,z,1);
			FurnaceSlotData1 = Level.getFurnaceSlotData(x,y,z,1);
			Level.setFurnaceSlot(x,y,z,1,0,0,0)
			FurnaceSlotId2 = Level.getFurnaceSlot(x,y,z,2);
			FurnaceSlotCount2 = Level.getFurnaceSlotCount(x,y,z,2);
			FurnaceSlotData2 = Level.getFurnaceSlotData(x,y,z,2);
			Level.setFurnaceSlot(x,y,z,2,0,0,0)
			setTile(x,y,z,0,0)
		}
		
		else if(blockId == 54){
			moveBlockId = blockId;
			moveBlockData = Level.getData(x,y,z)
			chestSlotId0 = Level.getChestSlot(x,y,z,0);
			chestSlotCount0 = Level.getChestSlotCount(x,y,z,0);
			chestSlotData0 = Level.getChestSlotData(x,y,z,0);
			Level.setChestSlot(x,y,z,0,0,0,0)
			chestSlotId1 = Level.getChestSlot(x,y,z,1);
			chestSlotCount1 = Level.getChestSlotCount(x,y,z,1);
			chestSlotData1 = Level.getChestSlotData(x,y,z,1);
			Level.setChestSlot(x,y,z,1,0,0,0)
			chestSlotId2 = Level.getChestSlot(x,y,z,2);
			chestSlotCount2 = Level.getChestSlotCount(x,y,z,2);
			chestSlotData2 = Level.getChestSlotData(x,y,z,2);
			Level.setChestSlot(x,y,z,2,0,0,0)
			chestSlotId3 = Level.getChestSlot(x,y,z,3);
			chestSlotCount3 = Level.getChestSlotCount(x,y,z,3);
			chestSlotData3 = Level.getChestSlotData(x,y,z,3);
			Level.setChestSlot(x,y,z,3,0,0,0)
			chestSlotId4 = Level.getChestSlot(x,y,z,4);
			chestSlotCount4 = Level.getChestSlotCount(x,y,z,4);
			chestSlotData4 = Level.getChestSlotData(x,y,z,4);
			Level.setChestSlot(x,y,z,4,0,0,0)
			chestSlotId5 = Level.getChestSlot(x,y,z,5);
			chestSlotCount5 = Level.getChestSlotCount(x,y,z,5);
			chestSlotData5 = Level.getChestSlotData(x,y,z,5);
			Level.setChestSlot(x,y,z,5,0,0,0)
			chestSlotId6 = Level.getChestSlot(x,y,z,6);
			chestSlotCount6 = Level.getChestSlotCount(x,y,z,6);
			chestSlotData6 = Level.getChestSlotData(x,y,z,6);
			Level.setChestSlot(x,y,z,6,0,0,0)
			chestSlotId7 = Level.getChestSlot(x,y,z,7);
			chestSlotCount7 = Level.getChestSlotCount(x,y,z,7);
			chestSlotData7 = Level.getChestSlotData(x,y,z,7);
			Level.setChestSlot(x,y,z,7,0,0,0)
			chestSlotId8 = Level.getChestSlot(x,y,z,8);
			chestSlotCount8 = Level.getChestSlotCount(x,y,z,8);
			chestSlotData8 = Level.getChestSlotData(x,y,z,8);
			Level.setChestSlot(x,y,z,8,0,0,0) 

			chestSlotId9 = Level.getChestSlot(x,y,z,9);
			chestSlotCount9 = Level.getChestSlotCount(x,y,z,9);
			chestSlotData9 = Level.getChestSlotData(x,y,z,9);
			Level.setChestSlot(x,y,z,9,0,0,0)
			chestSlotId10 = Level.getChestSlot(x,y,z,10);
			chestSlotCount10 = Level.getChestSlotCount(x,y,z,10);
			chestSlotData10 = Level.getChestSlotData(x,y,z,10);
			Level.setChestSlot(x,y,z,10,0,0,0)
			chestSlotId11 = Level.getChestSlot(x,y,z,11);
			chestSlotCount11 = Level.getChestSlotCount(x,y,z,11);
			chestSlotData11 = Level.getChestSlotData(x,y,z,11);
			Level.setChestSlot(x,y,z,11,0,0,0)
			chestSlotId12 = Level.getChestSlot(x,y,z,12);
			chestSlotCount12 = Level.getChestSlotCount(x,y,z,12);
			chestSlotData12 = Level.getChestSlotData(x,y,z,12);
			Level.setChestSlot(x,y,z,12,0,0,0)
			chestSlotId13 = Level.getChestSlot(x,y,z,13);
			chestSlotCount13 = Level.getChestSlotCount(x,y,z,13);
			chestSlotData13 = Level.getChestSlotData(x,y,z,13);
			Level.setChestSlot(x,y,z,13,0,0,0)
			chestSlotId14 = Level.getChestSlot(x,y,z,14);
			chestSlotCount14 = Level.getChestSlotCount(x,y,z,14);
			chestSlotData14 = Level.getChestSlotData(x,y,z,14);
			Level.setChestSlot(x,y,z,14,0,0,0)
			chestSlotId15 = Level.getChestSlot(x,y,z,15);
			chestSlotCount15 = Level.getChestSlotCount(x,y,z,15);
			chestSlotData15 = Level.getChestSlotData(x,y,z,15);
			Level.setChestSlot(x,y,z,15,0,0,0)
			chestSlotId16 = Level.getChestSlot(x,y,z,16);
			chestSlotCount16 = Level.getChestSlotCount(x,y,z,16);
			chestSlotData16 = Level.getChestSlotData(x,y,z,16);
			Level.setChestSlot(x,y,z,16,0,0,0)
			chestSlotId17 = Level.getChestSlot(x,y,z,17);
			chestSlotCount17 = Level.getChestSlotCount(x,y,z,17);
			chestSlotData17 = Level.getChestSlotData(x,y,z,17);
			Level.setChestSlot(x,y,z,17,0,0,0)

			chestSlotId18 = Level.getChestSlot(x,y,z,18);
			chestSlotCount18 = Level.getChestSlotCount(x,y,z,18);
			chestSlotData18 = Level.getChestSlotData(x,y,z,18);
			Level.setChestSlot(x,y,z,18,0,0,0)
			chestSlotId19 = Level.getChestSlot(x,y,z,19);
			chestSlotCount19 = Level.getChestSlotCount(x,y,z,19);
			chestSlotData19 = Level.getChestSlotData(x,y,z,19);
			Level.setChestSlot(x,y,z,19,0,0,0)
			chestSlotId20 = Level.getChestSlot(x,y,z,20);
			chestSlotCount20 = Level.getChestSlotCount(x,y,z,20);
			chestSlotData20 = Level.getChestSlotData(x,y,z,20);
			Level.setChestSlot(x,y,z,20,0,0,0)
			chestSlotId21 = Level.getChestSlot(x,y,z,21);
			chestSlotCount21 = Level.getChestSlotCount(x,y,z,21);
			chestSlotData21 = Level.getChestSlotData(x,y,z,21);
			Level.setChestSlot(x,y,z,21,0,0,0)
			chestSlotId22 = Level.getChestSlot(x,y,z,22);
			chestSlotCount22 = Level.getChestSlotCount(x,y,z,22);
			chestSlotData22 = Level.getChestSlotData(x,y,z,22);
			Level.setChestSlot(x,y,z,22,0,0,0)
			chestSlotId23 = Level.getChestSlot(x,y,z,23);
			chestSlotCount23 = Level.getChestSlotCount(x,y,z,23);
			chestSlotData23 = Level.getChestSlotData(x,y,z,23);
			Level.setChestSlot(x,y,z,23,0,0,0)
			chestSlotId24 = Level.getChestSlot(x,y,z,24);
			chestSlotCount24 = Level.getChestSlotCount(x,y,z,24);
			chestSlotData24 = Level.getChestSlotData(x,y,z,24);
			Level.setChestSlot(x,y,z,24,0,0,0)
			chestSlotId25 = Level.getChestSlot(x,y,z,25);
			chestSlotCount25 = Level.getChestSlotCount(x,y,z,25);
			chestSlotData25 = Level.getChestSlotData(x,y,z,25);
			Level.setChestSlot(x,y,z,25,0,0,0)
			chestSlotId26 = Level.getChestSlot(x,y,z,26);
			chestSlotCount26 = Level.getChestSlotCount(x,y,z,26);
			chestSlotData26 = Level.getChestSlotData(x,y,z,26);
			Level.setChestSlot(x,y,z,26,0,0,0)

			setTile(x,y,z,0,0)
		}
	}
	else if(moveBlock == 1){
		moveBlock = 0
		if(side == 0) y--
		else if(side == 1) y++
		else if(side == 2) z--
		else if(side == 3) z++
		else if(side == 4) x--
		else if(side == 5) x++
		setTile(x,y,z,moveBlockId,moveBlockData)
		if(moveBlockId == 61 || moveBlockId == 62){
			Level.setFurnaceSlot(x,y,z,0,FurnaceSlotId0,FurnaceSlotData0,FurnaceSlotCount0);
			Level.setFurnaceSlot(x,y,z,1,FurnaceSlotId1,FurnaceSlotData1,FurnaceSlotCount1);
			Level.setFurnaceSlot(x,y,z,2,FurnaceSlotId2,FurnaceSlotData2,FurnaceSlotCount2);
		}                          
		if(moveBlockId == 54){
			Level.setChestSlot(x,y,z,0,chestSlotId0,chestSlotData0,chestSlotCount0);
			Level.setChestSlot(x,y,z,1,chestSlotId1,chestSlotData1,chestSlotCount1);
			Level.setChestSlot(x,y,z,2,chestSlotId2,chestSlotData2,chestSlotCount2);
			Level.setChestSlot(x,y,z,3,chestSlotId3,chestSlotData3,chestSlotCount3);
			Level.setChestSlot(x,y,z,4,chestSlotId4,chestSlotData4,chestSlotCount4);
			Level.setChestSlot(x,y,z,5,chestSlotId5,chestSlotData5,chestSlotCount5);
			Level.setChestSlot(x,y,z,6,chestSlotId6,chestSlotData6,chestSlotCount6);
			Level.setChestSlot(x,y,z,7,chestSlotId7,chestSlotData7,chestSlotCount7);
			Level.setChestSlot(x,y,z,8,chestSlotId8,chestSlotData8,chestSlotCount8);

			Level.setChestSlot(x,y,z,9,chestSlotId9,chestSlotData9,chestSlotCount9);
			Level.setChestSlot(x,y,z,10,chestSlotId10,chestSlotData10,chestSlotCount10);
			Level.setChestSlot(x,y,z,11,chestSlotId11,chestSlotData11,chestSlotCount11);
			Level.setChestSlot(x,y,z,12,chestSlotId12,chestSlotData12,chestSlotCount12);
			Level.setChestSlot(x,y,z,13,chestSlotId13,chestSlotData13,chestSlotCount13);
			Level.setChestSlot(x,y,z,14,chestSlotId14,chestSlotData14,chestSlotCount14);
			Level.setChestSlot(x,y,z,15,chestSlotId15,chestSlotData15,chestSlotCount15);
			Level.setChestSlot(x,y,z,16,chestSlotId16,chestSlotData16,chestSlotCount16);
			Level.setChestSlot(x,y,z,17,chestSlotId17,chestSlotData17,chestSlotCount17);

			Level.setChestSlot(x,y,z,18,chestSlotId18,chestSlotData18,chestSlotCount18);
			Level.setChestSlot(x,y,z,19,chestSlotId19,chestSlotData19,chestSlotCount19);
			Level.setChestSlot(x,y,z,20,chestSlotId20,chestSlotData20,chestSlotCount20);
			Level.setChestSlot(x,y,z,21,chestSlotId21,chestSlotData21,chestSlotCount21);
			Level.setChestSlot(x,y,z,22,chestSlotId22,chestSlotData22,chestSlotCount22);
			Level.setChestSlot(x,y,z,23,chestSlotId23,chestSlotData23,chestSlotCount23);
			Level.setChestSlot(x,y,z,24,chestSlotId24,chestSlotData24,chestSlotCount24);
			Level.setChestSlot(x,y,z,25,chestSlotId25,chestSlotData25,chestSlotCount25);
			Level.setChestSlot(x,y,z,26,chestSlotId26,chestSlotData26,chestSlotCount26);
		}
	}
}


function removeOneBlockFromInventory(){
	for(i = 0;i<43;i++){
		//clientMessage("blockToSetToData 3 = "+data)
		//clientMessage("Checking for id:"+blockToSetTo+" data:"+blockToSetToData)
		if(Player.getInventorySlot(i) == blockToSetTo && Player.getInventorySlotData(i) == blockToSetToData){
			//clientMessage("Found id:"+blockToSetTo+" data:"+blockToSetToData)
			if(Player.getInventorySlotCount(i) < 2)
				Player.clearInventorySlot(i)
			else{
				amount = Player.getInventorySlotCount(i)
				Player.clearInventorySlot(i)
				Player.addItemInventory(blockToSetTo,amount-1,blockToSetToData)
			} 
			break
		}
	}
}

Player.checkForInventoryItem = function(id, amount, damage) {
	if(!amount) amount = 1;
	if(!damage) damage = 0;
	if(!id) id = 0;
	var count = 0;
	for(var i = 0; i < 255; i++) if(Player.getInventorySlot(i) == id && Player.getInventorySlotData(i) == damage) count += Player.getInventorySlotCount(i);
	return count >= amount;
};

/*
function downloadResources(){
	var activity = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();    
	activity.runOnUiThread(new java.lang.Runnable({ run: function() {
		try {
			shieldingFile = new java.io.File(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/shielding.png");
			if(!shieldingFile.exists()){
				filenames = ["portableHole","harmingI","harmingII","healing","floating","shielding"]
				urls = ["http://i.imgur.com/yDBOL4s.png","http://i.imgur.com/Oh3Xku8.png","http://i.imgur.com/J8jsMuH.png","http://i.imgur.com/MbM6m5j.png","http://i.imgur.com/y7vPPaa.png","http://i.imgur.com/T4NbQJz.png"]
				for(x = 0;x<6;x++){
					url = new java.net.URL(urls[x]);
					file = new java.io.File(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/com.mojang/WizardStaffMod/"+filenames[x]+".png");
					urlConnection = url.openConnection();
					inputStream = urlConnection.getInputStream();
					bufferedInputStream = new java.io.BufferedInputStream(inputStream);
					byteArrayBuffer = new org.apache.http.util.ByteArrayBuffer(50);
					current = 0;
					while ((current = bufferedInputStream.read()) != -1){
						byteArrayBuffer.append( current);
					}
					fileOutputStream = new java.io.FileOutputStream(file);
					fileOutputStream.write(byteArrayBuffer.toByteArray());
					fileOutputStream.close();
				}
			}
		}catch(e){
			print(e);
		}
	}}));
}
*/

/*
Focus of: 
- Portable Hole
- Harming (6 DMG)
- Harming II (10 DMG)
- Healing
- Floating
- Shielding
*/




