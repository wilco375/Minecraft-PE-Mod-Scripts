Minecraft.Localization
======================

Collaborative repository for external translators.
